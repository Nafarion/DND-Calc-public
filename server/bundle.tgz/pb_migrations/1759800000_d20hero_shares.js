/// <reference path="../pb_data/types.d.ts" />

/**
 * Короткие ссылки «Поделиться персонажем»: таблица shares.
 *
 * В записи лежит тот же сжатый лист, что раньше целиком стоял в адресе после
 * #share=, а в ссылке остаётся только номер записи (#s=…). Создать запись может
 * любой посетитель, открыть — любой, кто знает номер; список записей закрыт,
 * изменить или удалить их можно только в панели управления. Номер — 10 случайных
 * латинских букв и цифр, подобрать чужой практически невозможно. От засорения
 * базы — ограничение: не больше 30 ссылок в час с одного адреса.
 */
migrate(
  (app) => {
    const shares = new Collection({
      type: 'base',
      name: 'shares',
      listRule: null,
      viewRule: '',
      // Номер записи выдаёт сервер — свой задать нельзя.
      createRule: '@request.body.id:isset = false',
      updateRule: null,
      deleteRule: null,
      fields: [
        {
          name: 'id',
          type: 'text',
          primaryKey: true,
          system: true,
          required: true,
          min: 10,
          max: 10,
          pattern: '^[0-9A-Za-z]+$',
          autogeneratePattern: '[0-9A-Za-z]{10}',
        },
        // Сжатый лист: «z» + deflate-raw в base64url или «j» + JSON в base64url.
        { name: 'data', type: 'text', required: true, max: 60000, pattern: '^[zj][0-9A-Za-z_-]+$' },
        { name: 'created', type: 'autodate', onCreate: true },
      ],
    })
    app.save(shares)

    const settings = app.settings()
    settings.rateLimits.rules = [
      ...settings.rateLimits.rules.filter((rule) => rule.label !== 'shares:create'),
      { label: 'shares:create', audience: '', duration: 3600, maxRequests: 30 },
    ]
    app.save(settings)
  },
  (app) => {
    app.delete(app.findCollectionByNameOrId('shares'))
    const settings = app.settings()
    settings.rateLimits.rules = settings.rateLimits.rules.filter((rule) => rule.label !== 'shares:create')
    app.save(settings)
  },
)
