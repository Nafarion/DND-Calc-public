/// <reference path="../pb_data/types.d.ts" />

/**
 * Сайт переименован в D20Hero: имя отправителя и тексты писем.
 * Тема писем берёт название из {APP_NAME}, поэтому меняем и его.
 */
migrate(
  (app) => {
    const settings = app.settings()
    settings.meta.appName = 'D20Hero'
    settings.meta.senderName = 'D20Hero'
    app.save(settings)

    const users = app.findCollectionByNameOrId('users')
    const rename = (text) => text.split('DND Calc').join('D20Hero')
    users.verificationTemplate.body = rename(users.verificationTemplate.body)
    users.resetPasswordTemplate.body = rename(users.resetPasswordTemplate.body)
    app.save(users)
  },
  (app) => {
    const settings = app.settings()
    settings.meta.appName = 'DND Calc'
    settings.meta.senderName = 'DND Calc'
    app.save(settings)
  },
)
