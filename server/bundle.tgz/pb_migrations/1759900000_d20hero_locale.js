/// <reference path="../pb_data/types.d.ts" />

/**
 * Язык писем аккаунта (№134, английский сайт d20hero.online): поле locale
 * ('en' — английские письма со ссылками на английский сайт, пусто — русские).
 * Его ставит сервер по сайту, с которого пришёл запрос (pb_hooks/locale.pb.js).
 */
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users')
    if (!users.fields.getByName('locale')) {
      users.fields.add(new TextField({ name: 'locale', max: 5 }))
      app.save(users)
    }
  },
  (app) => {
    const users = app.findCollectionByNameOrId('users')
    users.fields.removeByName('locale')
    app.save(users)
  },
)
