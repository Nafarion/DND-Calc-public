/// <reference path="../pb_data/types.d.ts" />

/**
 * Начальная настройка сервера аккаунтов DND Calc.
 *
 *  - таблица characters: каждый пользователь видит и меняет только своих
 *    персонажей, при удалении аккаунта персонажи удаляются вместе с ним;
 *  - вход только после подтверждения почты;
 *  - письма на русском, ссылки из них ведут на сайт, а не в админку;
 *  - ограничение частоты запросов и ежедневные резервные копии.
 *
 * Адрес сайта берётся из переменной окружения DND_SITE_URL, адрес самого
 * сервера — из DND_API_URL (их задаёт install.sh в службе systemd).
 */
migrate(
  (app) => {
    const siteUrl = ($os.getenv('DND_SITE_URL') || 'https://d20hero.ru').replace(/\/+$/, '')
    const apiUrl = ($os.getenv('DND_API_URL') || 'http://127.0.0.1:8090').replace(/\/+$/, '')

    // --- общие настройки
    const settings = app.settings()
    settings.meta.appName = 'DND Calc'
    settings.meta.appURL = apiUrl
    settings.meta.senderName = 'DND Calc'
    settings.rateLimits.enabled = true
    settings.backups.cron = '0 3 * * *'
    settings.backups.cronMaxKeep = 7
    app.save(settings)

    // --- пользователи
    const users = app.findCollectionByNameOrId('users')
    users.authRule = 'verified = true'
    users.authAlert.enabled = false

    const button = (href, text) =>
      `<p><a class="btn" href="${href}" target="_blank" rel="noopener">${text}</a></p>`

    users.verificationTemplate = {
      subject: 'Подтвердите почту — {APP_NAME}',
      body:
        '<p>Здравствуйте!</p>' +
        '<p>Чтобы завершить регистрацию в конструкторе персонажей DND Calc, подтвердите адрес почты.</p>' +
        button(`${siteUrl}/#verify={TOKEN}`, 'Подтвердить почту') +
        '<p>Если вы не регистрировались, просто не обращайте внимания на это письмо.</p>',
    }
    users.resetPasswordTemplate = {
      subject: 'Новый пароль — {APP_NAME}',
      body:
        '<p>Здравствуйте!</p>' +
        '<p>Кто-то, возможно вы, попросил сменить пароль от аккаунта DND Calc.</p>' +
        button(`${siteUrl}/#reset={TOKEN}`, 'Задать новый пароль') +
        '<p>Если вы не просили сменить пароль, ничего делать не нужно — старый продолжит работать.</p>',
    }
    app.save(users)

    // --- персонажи
    const characters = new Collection({
      type: 'base',
      name: 'characters',
      listRule: 'user = @request.auth.id',
      viewRule: 'user = @request.auth.id',
      createRule: "@request.auth.id != '' && @request.body.user = @request.auth.id",
      // Владельца персонажа сменить нельзя.
      updateRule:
        'user = @request.auth.id && (@request.body.user:isset = false || @request.body.user = @request.auth.id)',
      deleteRule: 'user = @request.auth.id',
      fields: [
        {
          name: 'user',
          type: 'relation',
          required: true,
          collectionId: users.id,
          maxSelect: 1,
          cascadeDelete: true,
        },
        // id персонажа из приложения — уникален в пределах пользователя.
        { name: 'charId', type: 'text', required: true, max: 100 },
        { name: 'name', type: 'text', max: 200 },
        { name: 'data', type: 'json', required: true, maxSize: 2000000 },
        { name: 'created', type: 'autodate', onCreate: true },
        { name: 'updated', type: 'autodate', onCreate: true, onUpdate: true },
      ],
      indexes: [
        'CREATE UNIQUE INDEX idx_characters_user_char ON characters (user, charId)',
        'CREATE INDEX idx_characters_user_updated ON characters (user, updated)',
      ],
    })
    app.save(characters)
  },
  (app) => {
    app.delete(app.findCollectionByNameOrId('characters'))
  },
)
