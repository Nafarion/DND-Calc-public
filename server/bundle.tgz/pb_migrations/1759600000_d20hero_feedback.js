/// <reference path="../pb_data/types.d.ts" />

/**
 * Обратная связь с сайта: таблица feedback.
 *
 * Написать может любой посетитель, а читать сообщения — только администратор
 * в панели управления (правила просмотра и изменения пустые). От спама
 * защищают капча (pb_hooks/feedback.pb.js) и ограничение: не больше пяти
 * сообщений в час с одного адреса.
 */
migrate(
  (app) => {
    const feedback = new Collection({
      type: 'base',
      name: 'feedback',
      listRule: null,
      viewRule: null,
      createRule: '',
      updateRule: null,
      deleteRule: null,
      fields: [
        { name: 'message', type: 'text', required: true, min: 3, max: 4000 },
        // Как ответить: почта, Telegram — по желанию автора.
        { name: 'contact', type: 'text', max: 200 },
        // Страница, с которой написали, — помогает понять, о чём речь.
        { name: 'page', type: 'text', max: 300 },
        { name: 'created', type: 'autodate', onCreate: true },
      ],
      indexes: ['CREATE INDEX idx_feedback_created ON feedback (created)'],
    })
    app.save(feedback)

    const settings = app.settings()
    settings.rateLimits.rules = [
      ...settings.rateLimits.rules.filter((rule) => rule.label !== 'feedback:create'),
      { label: 'feedback:create', audience: '', duration: 3600, maxRequests: 5 },
    ]
    app.save(settings)
  },
  (app) => {
    app.delete(app.findCollectionByNameOrId('feedback'))
    const settings = app.settings()
    settings.rateLimits.rules = settings.rateLimits.rules.filter((rule) => rule.label !== 'feedback:create')
    app.save(settings)
  },
)
