/// <reference path="../pb_data/types.d.ts" />

/**
 * Логин пользователя: задаётся при регистрации, показывается на сайте вместо
 * почты, по нему тоже можно входить. Регистр не важен: «Rogue» и «rogue» —
 * один и тот же логин. Только латиница: SQLite сравнивает без учёта регистра
 * лишь латинские буквы, и кириллические «Вася» и «вася» оказались бы разными
 * логинами. У старых аккаунтов логин пустой, его можно задать в кабинете.
 */
migrate(
  (app) => {
    const users = app.findCollectionByNameOrId('users')

    users.fields.add(
      new TextField({
        name: 'username',
        required: false,
        min: 3,
        max: 24,
        pattern: '^[0-9A-Za-z_.-]+$',
      }),
    )
    users.addIndex('idx_users_username', true, 'username COLLATE NOCASE', "username != ''")
    users.passwordAuth.identityFields = ['email', 'username']

    app.save(users)
  },
  (app) => {
    const users = app.findCollectionByNameOrId('users')
    users.passwordAuth.identityFields = ['email']
    users.removeIndex('idx_users_username')
    users.fields.removeByName('username')
    app.save(users)
  },
)
