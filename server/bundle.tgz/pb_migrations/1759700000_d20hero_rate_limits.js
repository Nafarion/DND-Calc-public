/// <reference path="../pb_data/types.d.ts" />

/**
 * Ограничения на действия, после которых сервер отправляет письма. Без них
 * бот мог бы регистрировать чужие адреса или заваливать их письмами о сбросе
 * пароля — почтовики быстро сочли бы домен спамерским. Человеку этих лимитов
 * хватает с запасом; считаются они для каждого IP отдельно.
 */
const RULES = [
  { label: 'users:create', audience: '', duration: 3600, maxRequests: 5 },
  { label: 'users:requestVerification', audience: '', duration: 3600, maxRequests: 5 },
  { label: 'users:requestPasswordReset', audience: '', duration: 3600, maxRequests: 5 },
  { label: 'users:requestEmailChange', audience: '', duration: 3600, maxRequests: 5 },
]
const LABELS = RULES.map((rule) => rule.label)

migrate(
  (app) => {
    const settings = app.settings()
    settings.rateLimits.rules = [
      ...settings.rateLimits.rules.filter((rule) => !LABELS.includes(rule.label)),
      ...RULES,
    ]
    app.save(settings)
  },
  (app) => {
    const settings = app.settings()
    settings.rateLimits.rules = settings.rateLimits.rules.filter((rule) => !LABELS.includes(rule.label))
    app.save(settings)
  },
)
