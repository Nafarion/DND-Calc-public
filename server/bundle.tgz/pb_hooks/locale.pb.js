/// <reference path="../pb_data/types.d.ts" />

// Письма на языке сайта (№134): регистрация, повторное письмо и сброс пароля с английского
// сайта (d20hero.online) — английские письма со ссылками на него; с русского — как раньше.

onRecordCreateRequest((e) => {
  const locale = require(`${__hooks}/locale.js`).fromRequest(e)
  if (locale) e.record.set('locale', locale)
  e.next()
}, 'users')

onRecordRequestVerificationRequest((e) => {
  const l = require(`${__hooks}/locale.js`)
  l.remember(e.app, e.record, l.fromRequest(e))
  e.next()
}, 'users')

onRecordRequestPasswordResetRequest((e) => {
  const l = require(`${__hooks}/locale.js`)
  l.remember(e.app, e.record, l.fromRequest(e))
  e.next()
}, 'users')

onRecordAuthWithOAuth2Request((e) => {
  const l = require(`${__hooks}/locale.js`)
  const locale = l.fromRequest(e)
  if (e.record) l.remember(e.app, e.record, locale)
  e.next()
  if (!e.record || e.record.get('locale') === locale) return
  l.remember(e.app, e.record, locale)
}, 'users')

onMailerRecordVerificationSend((e) => {
  const l = require(`${__hooks}/locale.js`)
  const site = l.englishSite()
  if (e.record.get('locale') === 'en' && site) {
    const token = e.meta.token
    e.message.subject = 'Confirm your email — D20Hero'
    e.message.html =
      '<p>Hello!</p>' +
      '<p>To finish signing up for the D20Hero character builder, please confirm your email address.</p>' +
      l.button(`${site}/#verify=${token}`, 'Confirm email') +
      "<p>If you didn't sign up, just ignore this email.</p>"
    e.message.text = ''
  }
  e.next()
}, 'users')

onMailerRecordPasswordResetSend((e) => {
  const l = require(`${__hooks}/locale.js`)
  const site = l.englishSite()
  if (e.record.get('locale') === 'en' && site) {
    const token = e.meta.token
    e.message.subject = 'New password — D20Hero'
    e.message.html =
      '<p>Hello!</p>' +
      '<p>Someone, possibly you, asked to change the password for your D20Hero account.</p>' +
      l.button(`${site}/#reset=${token}`, 'Set a new password') +
      "<p>If you didn't ask to change your password, you don't need to do anything — your old password will keep working.</p>"
    e.message.text = ''
  }
  e.next()
}, 'users')
