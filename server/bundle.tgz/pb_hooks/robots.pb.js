/// <reference path="../pb_data/types.d.ts" />

// Сервер аккаунтов — не для поисковиков: API и панель администратора
// индексировать незачем, сайт со справочником живёт на основном домене.
routerAdd('GET', '/robots.txt', (e) => {
  return e.string(200, 'User-agent: *\nDisallow: /\n')
})
