/// <reference path="../pb_data/types.d.ts" />

/**
 * Язык и сайт для писем (№134). Английский сайт перечислен в DND_EXTRA_SITES (install.sh,
 * EXTRA_SITES); запрос с него определяется по заголовку Origin (или Referer).
 */
function hostOf(url) {
  return String(url || '').replace(/^[a-z]+:\/\//i, '').replace(/[/:].*$/, '').replace(/^www\./, '').toLowerCase()
}

function englishSite() {
  const list = String($os.getenv('DND_EXTRA_SITES') || '')
    .split(',')
    .map((s) => s.trim().replace(/\/+$/, ''))
    .filter(Boolean)
  return list.length ? (/^https?:\/\//.test(list[0]) ? list[0] : 'https://' + list[0]) : ''
}

module.exports = {
  /** 'en', если запрос пришёл с английского сайта, иначе ''. */
  fromRequest: (e) => {
    const site = englishSite()
    if (!site) return ''
    const headers = e.requestInfo().headers
    const from = hostOf(headers['origin'] || headers['referer'])
    return from && from === hostOf(site) ? 'en' : ''
  },

  /** Запомнить язык в аккаунте, если он изменился. */
  remember: (app, record, locale) => {
    if (!record || String(record.get('locale') || '') === locale) return
    record.set('locale', locale)
    try {
      app.saveNoValidate(record)
    } catch (err) {
      console.log('locale save failed:', err)
    }
  },

  englishSite: englishSite,

  button: (href, text) => `<p><a class="btn" href="${href}" target="_blank" rel="noopener">${text}</a></p>`,
}
