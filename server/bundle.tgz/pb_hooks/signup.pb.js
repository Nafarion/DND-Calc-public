/// <reference path="../pb_data/types.d.ts" />

// Регистрация на уже занятую почту.
//
// Уникальность почты в PocketBase учитывает регистр: «Alice@mail.ru» и
// «alice@mail.ru» были бы двумя аккаунтами. Здесь адрес сверяется без учёта
// регистра, и на занятый адрес сервер отвечает той же ошибкой, что и сам
// PocketBase, — сайт показывает «Эта почта уже зарегистрирована».
// Капча (captcha.pb.js) срабатывает раньше, частоту ограничивает правило users:create.

onRecordCreateRequest((e) => {
  // Администратор в панели создаёт пользователей как обычно.
  if (e.hasSuperuserAuth()) return e.next()

  const email = String(e.requestInfo().body.email || '').trim()
  let existing = null
  if (email) {
    try {
      existing = e.app.findFirstRecordByFilter('users', 'email:lower = {:email}', { email: email.toLowerCase() })
    } catch (err) {
      existing = null
    }
  }
  if (!existing) return e.next()

  throw new BadRequestError('Эта почта уже зарегистрирована. Войдите или восстановите пароль.', {
    email: new ValidationError('validation_not_unique', 'Value must be unique.'),
  })
}, 'users')
