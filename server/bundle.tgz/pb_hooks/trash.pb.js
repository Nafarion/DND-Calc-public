// Delete only rows that are still in the trash at the time of the sweep.
cronAdd("purge_character_trash", "*/15 * * * *", () => {
  $app.db().newQuery(`
    DELETE FROM characters
    WHERE json_type(data, '$.trashedAt') IN ('integer', 'real')
      AND json_extract(data, '$.trashedAt') <= {:cutoff}
  `).bind({ cutoff: Date.now() - 10 * 24 * 60 * 60 * 1000 }).execute()
})
