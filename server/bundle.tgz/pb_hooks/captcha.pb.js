/// <reference path="../pb_data/types.d.ts" />

// Капча на действиях, которые создают аккаунт или отправляют письмо
// постороннему адресу. На вход капча не нужна: от подбора пароля защищает
// ограничение частоты попыток. Код проверки — в captcha.js.

onRecordCreateRequest((e) => {
  require(`${__hooks}/captcha.js`).check(e)
  e.next()
}, 'users')

onRecordRequestPasswordResetRequest((e) => {
  require(`${__hooks}/captcha.js`).check(e)
  e.next()
}, 'users')
