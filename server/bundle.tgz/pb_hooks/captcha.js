/// <reference path="../pb_data/types.d.ts" />

/**
 * Проверка «я не робот». Русский сайт — Яндекс SmartCaptcha (ключ SMARTCAPTCHA_SERVER_KEY),
 * английский (d20hero.online, №134) — Cloudflare Turnstile (ключ TURNSTILE_SECRET_KEY); он
 * присылает заголовок X-Captcha-Provider: turnstile. Без ключей запросы проходят как раньше.
 * Токен капчи сайт присылает в заголовке X-Captcha-Token.
 */
function reject(message, code) {
  throw new BadRequestError(message, { captcha: new ValidationError(code, message) })
}

/** Cloudflare Turnstile: POST siteverify, ответ { success: true|false }. */
function checkTurnstile(e, secret, token) {
  const url = $os.getenv('TURNSTILE_VALIDATE_URL') || 'https://challenges.cloudflare.com/turnstile/v0/siteverify'
  let res
  try {
    res = $http.send({
      url: url,
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body:
        'secret=' + encodeURIComponent(secret) +
        '&response=' + encodeURIComponent(token) +
        '&remoteip=' + encodeURIComponent(e.realIP()),
      timeout: 10,
    })
  } catch (err) {
    // Сервис капчи недоступен — людей не блокируем (как и с SmartCaptcha).
    console.log('turnstile unavailable:', err)
    return
  }
  if (res.statusCode !== 200) {
    console.log('turnstile status', res.statusCode)
    return
  }
  if (!res.json || res.json.success !== true) {
    reject("The \"I'm not a robot\" check failed, please try again.", 'captcha_failed')
  }
}

module.exports = {
  check: (e) => {
    const yandexSecret = $os.getenv('SMARTCAPTCHA_SERVER_KEY')
    const turnstileSecret = $os.getenv('TURNSTILE_SECRET_KEY')
    if (!yandexSecret && !turnstileSecret) return
    // Администратор в панели управления капчу не проходит.
    if (e.hasSuperuserAuth()) return
    // Первый вход через внешний сервис создаёт аккаунт внутренним
    // запросом без токена капчи; от ботов здесь защищает сам внешний сервис.
    if (e.requestInfo().context === 'oauth2') return

    // Заголовки приходят в нижнем регистре, «-» заменены на «_».
    const headers = e.requestInfo().headers
    const token = headers['x_captcha_token']
    if (headers['x_captcha_provider'] === 'turnstile') {
      // Без ключа Turnstile запрос с английского сайта не должен обходить капчу русского.
      if (!turnstileSecret) {
        if (yandexSecret) reject("Please confirm you're not a robot.", 'captcha_required')
        return
      }
      if (!token) reject("Please confirm you're not a robot.", 'captcha_required')
      checkTurnstile(e, turnstileSecret, token)
      return
    }
    const secret = yandexSecret
    if (!secret) return

    if (!token) {
      throw new BadRequestError('Подтвердите, что вы не робот.', {
        captcha: new ValidationError('captcha_required', 'Подтвердите, что вы не робот.'),
      })
    }

    const base = $os.getenv('SMARTCAPTCHA_VALIDATE_URL') || 'https://smartcaptcha.yandexcloud.net/validate'
    const url =
      base +
      '?secret=' + encodeURIComponent(secret) +
      '&token=' + encodeURIComponent(token) +
      '&ip=' + encodeURIComponent(e.realIP())

    let res
    try {
      res = $http.send({ url: url, method: 'GET', timeout: 10 })
    } catch (err) {
      // Сервис капчи недоступен — по рекомендации Яндекса не блокируем людей.
      console.log('smartcaptcha unavailable:', err)
      return
    }
    if (res.statusCode !== 200) {
      console.log('smartcaptcha status', res.statusCode)
      return
    }
    if (!res.json || res.json.status !== 'ok') {
      throw new BadRequestError('Проверка «я не робот» не пройдена, попробуйте ещё раз.', {
        captcha: new ValidationError('captcha_failed', 'Проверка не пройдена.'),
      })
    }
  },
}
