/// <reference path="../pb_data/types.d.ts" />

/**
 * Проверка Яндекс SmartCaptcha. Включается, когда в окружении сервера задан
 * ключ SMARTCAPTCHA_SERVER_KEY; без него запросы проходят как раньше.
 * Токен капчи сайт присылает в заголовке X-Captcha-Token.
 */
module.exports = {
  check: (e) => {
    const secret = $os.getenv('SMARTCAPTCHA_SERVER_KEY')
    if (!secret) return
    // Администратор в панели управления капчу не проходит.
    if (e.hasSuperuserAuth()) return

    // Заголовки приходят в нижнем регистре, «-» заменены на «_».
    const token = e.requestInfo().headers['x_captcha_token']
    if (!token) {
      throw new BadRequestError('Подтвердите, что вы не робот.', {
        captcha: new ValidationError('captcha_required', 'Подтвердите, что вы не робот.'),
      })
    }

    const base = $os.getenv('SMARTCAPTCHA_VALIDATE_URL') || 'https://smartcaptcha.yandexcloud.net/validate'
    const url =
      base +
      '?secret=' + encodeURIComponent(secret) +
      '&token=' + encodeURIComponent(token) +
      '&ip=' + encodeURIComponent(e.realIP())

    let res
    try {
      res = $http.send({ url: url, method: 'GET', timeout: 10 })
    } catch (err) {
      // Сервис капчи недоступен — по рекомендации Яндекса не блокируем людей.
      console.log('smartcaptcha unavailable:', err)
      return
    }
    if (res.statusCode !== 200) {
      console.log('smartcaptcha status', res.statusCode)
      return
    }
    if (!res.json || res.json.status !== 'ok') {
      throw new BadRequestError('Проверка «я не робот» не пройдена, попробуйте ещё раз.', {
        captcha: new ValidationError('captcha_failed', 'Проверка не пройдена.'),
      })
    }
  },
}
