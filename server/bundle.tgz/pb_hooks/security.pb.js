/// <reference path="../pb_data/types.d.ts" />

// Заголовки безопасности для всех ответов сервера аккаунтов: браузер всегда ходит сюда только
// по https (HSTS, год) и не передаёт другим сайтам полный адрес страницы. Остальные
// (nosniff, X-Frame-Options) PocketBase ставит сам.
routerUse((e) => {
  e.response.header().set('Strict-Transport-Security', 'max-age=31536000')
  e.response.header().set('Referrer-Policy', 'strict-origin-when-cross-origin')
  return e.next()
})
