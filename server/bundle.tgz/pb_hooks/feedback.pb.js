/// <reference path="../pb_data/types.d.ts" />

// Сообщения с сайта: капча на отправку (как при регистрации) и, если задан
// адрес FEEDBACK_EMAIL, копия каждого сообщения на эту почту.

onRecordCreateRequest((e) => {
  require(`${__hooks}/captcha.js`).check(e)
  e.next()
}, 'feedback')

onRecordAfterCreateSuccess((e) => {
  e.next()
  const to = $os.getenv('FEEDBACK_EMAIL')
  if (!to) return

  const escape = (text) =>
    String(text || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
  const record = e.record
  const settings = e.app.settings()
  const text = String(record.get('message') || '')
  const contact = String(record.get('contact') || '').trim()
  const page = String(record.get('page') || '')
  // Если автор оставил почту, «Ответить» в почтовой программе пишет сразу ему.
  const replyTo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contact) ? contact : ''

  try {
    const message = new MailerMessage({
      from: { address: settings.meta.senderAddress, name: settings.meta.senderName },
      to: [{ address: to }],
      subject: 'Сообщение с сайта D20Hero',
      html:
        '<p style="white-space:pre-wrap">' + escape(text) + '</p>' +
        '<p><b>Как ответить:</b> ' + (escape(contact) || 'не указано') + '<br>' +
        '<b>Страница:</b> ' + (escape(page) || '—') + '</p>',
      // Текстовая версия рядом с HTML — почтовики меньше считают такие письма спамом.
      text:
        text + '\n\nКак ответить: ' + (contact || 'не указано') + '\nСтраница: ' + (page || '—'),
      headers: replyTo ? { 'Reply-To': replyTo } : {},
    })
    e.app.newMailClient().send(message)
  } catch (err) {
    // Сообщение уже сохранено в панели управления — письмо лишь копия.
    console.log('feedback mail failed:', err)
  }
}, 'feedback')
