// Append after localized templates have rendered, including direct feedback emails.
onMailerSend((e) => {
  const url = 'https://t.me/d20hero'
  const footer = '<p>Telegram · <a href="' + url + '">@d20hero</a></p>'
  if (e.message.html) {
    e.message.html = /<\/body\s*>/i.test(e.message.html)
      ? e.message.html.replace(/<\/body\s*>/i, footer + '$&')
      : e.message.html + footer
  }
  if (e.message.text) e.message.text += '\n\nTelegram · ' + url
  e.next()
})
